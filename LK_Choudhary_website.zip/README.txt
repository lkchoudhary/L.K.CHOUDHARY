L.K. CHOUDHARY PERSONAL WEBSITE

Your Facebook link is already added:
https://www.facebook.com/share/1M4tffSuWC/

TO ADD YOUR PHOTO:
1. Put your photo in this folder.
2. Rename it exactly: profile.jpg

TO ADD YOUR PHONE NUMBER:
Open index.html and replace:
YOUR NUMBER
with your phone/WhatsApp number.

TO ADD MORE SOCIAL MEDIA:
Copy the Facebook button/link in index.html and replace the URL with your Instagram/YouTube/etc.

FREE HOSTING:
You can upload these files to GitHub Pages, Netlify, or Cloudflare Pages.
